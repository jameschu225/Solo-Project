package com.ShareFly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareFlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShareFlyApplication.class, args);
	}

}
