package com.ShareFly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShareFlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
